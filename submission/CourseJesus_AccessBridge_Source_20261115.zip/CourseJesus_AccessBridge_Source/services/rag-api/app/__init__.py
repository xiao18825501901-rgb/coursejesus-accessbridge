"""CourseMate RAG API package."""
