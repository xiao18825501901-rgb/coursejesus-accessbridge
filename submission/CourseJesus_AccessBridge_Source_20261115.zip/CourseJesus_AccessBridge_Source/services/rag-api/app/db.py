import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from app.config import Settings

V3_MIGRATIONS = (
    "011_learning_workspaces.sql",
    "012_learning_journeys.sql",
    "013_document_versions_and_artifacts.sql",
    "014_knowledge_registry_and_trees.sql",
    "015_teaching_plans_and_delivery_evidence.sql",
    "016_problem_runtime_and_bridges.sql",
    "017_assessment_runtime.sql",
    "018_grade_policy_and_snapshots.sql",
    "019_scoped_publication_reviews.sql",
    "020_official_publication_resource_locks.sql",
    "021_model_call_budget_reservations.sql",
    "022_shell_delivery_evidence.sql",
    "023_official_knowledge_draft_fingerprint.sql",
    "024_official_knowledge_generation_plans.sql",
    "025_campus_display_and_verification.sql",
    "026_learning_start_events.sql",
    "027_assessment_preparation_reference.sql",
    "028_jev_decision_receipts.sql",
    "029_entity_relations.sql",
    "030_feedback_reports.sql",
    "031_canvas_import.sql",
    "032_campus_material.sql",
    "033_canvas_local_bridge.sql",
    "034_canvas_oauth_states.sql",
    "035_canvas_task_credential.sql",
    "036_question_engine_provenance.sql",
    "037_practice_question_interactions.sql",
    "038_assessment_question_slots.sql",
    "039_practice_operation_reconciliation.sql",
    "040_configurable_assessments.sql",
    "041_canvas_local_bridge_client.sql",
    "042_auto_knowledge_map.sql",
    "043_auto_knowledge_model_attempts.sql",
    "044_auto_knowledge_background_budget_scope.sql",
    "045_auto_knowledge_local_recovery_reasons.sql",
    "046_auto_knowledge_legacy_feedback_recovery.sql",
    "047_auto_knowledge_staged_course_workspace_recovery.sql",
    "048_auto_knowledge_required_item_repair.sql",
    "049_auto_knowledge_base_prompt_hash_restore.sql",
    "050_auto_knowledge_unique_key_repair.sql",
    "051_auto_knowledge_evidence_scope_repair.sql",
    "052_auto_knowledge_evidence_scope_normalization.sql",
    "053_auto_knowledge_evidence_scope_normalization_retry.sql",
    "054_auto_knowledge_per_shard_evidence_recovery_receipts.sql",
    "055_auto_knowledge_evidence_scope_resume.sql",
    "056_compact_knowledge_tree_budget.sql",
    "057_durable_object_storage.sql",
    "058_compact_tree_lineage.sql",
    "059_storage_document_versions.sql",
    "060_learning_loop_delivery.sql",
    "061_auto_knowledge_spec_split_recovery.sql",
    "062_auto_knowledge_spec_split_resume.sql",
    "063_auto_knowledge_spec_split_source_replay.sql",
    "064_durable_assessment_preparation.sql",
    "065_hybrid_quality_review.sql",
    # 065 is not modified.  A provider failure needs its own append-only table
    # because hybrid_review_calls is keyed on (revision, role, input_hash) and
    # a recorded failure there would block the legitimate retry of that input.
    "066_hybrid_provider_failure_ledger.sql",
    "067_visual_learning_engine.sql",
    "068_visual_assistance_preferences.sql",
    "069_visual_renderer_cold_start_receipts.sql",
    "070_assessment_start_intents.sql",
    "071_assessment_operation_recovery_receipts.sql",
    # 072 is a conditional ADD COLUMN pair; its ledger row below is the
    # replay guard for SQLite's non-idempotent ALTER TABLE statements.
    "072_assessment_preparation_retry_epochs.sql",
    "073_generic_llm_call_ledger.sql",
    "074_new_private_tree_origins.sql",
    "075_learning_role_routes.sql",
    "076_learning_transport_audit.sql",
    "077_metered_strong_review_roles.sql",
    "078_point_assessment_plans.sql",
    "079_point_question_provenance.sql",
    "080_visual_owner_review_immutability.sql",
    "081_visual_runtime_drain.sql",
    "082_assessment_slot_preparation_progress.sql",
    "083_point_question_cross_configuration_reuse.sql",
    "084_deterministic_point_questions.sql",
    "085_source_bound_student_entry.sql",
    "086_auto_knowledge_internal_workspace_recovery.sql",
    "087_auto_knowledge_recovery_receipt_constraint_repair.sql",
    "088_auto_knowledge_append_budget.sql",
    "089_bounded_append_local_resume.sql",
)
# Migrations 038 and 039 successively widen both model-call ledgers. Replaying
# either older rebuild on a database that already has the newer role set would
# temporarily narrow the enum before the current migration could repair it.
# Keep historical SQL immutable and skip only a superseded rebuild after its
# superseding version has committed its ledger row.
V3_REPLAY_SUPERSEDED_BY = {
    # Migrations 013 and 016 contain legacy backfills over the V2 chunks
    # table. Their ledger rows are written only after the backfill commits, so
    # replaying an applied migration can only repeat a full-table scan. On a
    # multi-gigabyte corpus that delayed every service restart by several
    # minutes and left the API without a listening socket. A missing ledger
    # row still runs the migration normally.
    "013_document_versions_and_artifacts.sql": 13,
    "016_problem_runtime_and_bridges.sql": 16,
    "086_auto_knowledge_internal_workspace_recovery.sql": 86,
    "085_source_bound_student_entry.sql": 85,
    "084_deterministic_point_questions.sql": 84,
    "083_point_question_cross_configuration_reuse.sql": 83,
    "087_auto_knowledge_recovery_receipt_constraint_repair.sql": 87,
    "088_auto_knowledge_append_budget.sql": 88,
    "089_bounded_append_local_resume.sql": 89,
    "078_point_assessment_plans.sql": 78,
    "077_metered_strong_review_roles.sql": 77,
    # Migration 021's legacy evidence backfill is safe while 021 is first
    # applied (or deliberately restored after its ledger row is removed), but
    # must not replay on a schema-39 database. Migration 039 intentionally
    # allows repeated roles, so the old UNIQUE guard no longer prevents the
    # backfill from duplicating already-metered calls on every restart.
    "021_model_call_budget_reservations.sql": 39,
    "027_assessment_preparation_reference.sql": 38,
    "038_assessment_question_slots.sql": 39,
    # Migration 044 appends quota_scope. Replaying 039 afterwards would rebuild
    # the ledger with its historical 12-column shape and SELECT * 13 values.
    "039_practice_operation_reconciliation.sql": 44,
    "040_configurable_assessments.sql": 40,
    # Migration 045 rebuilds an immutable ledger to widen a CHECK enum and is
    # intentionally one-shot. Once its own ledger row exists, never replay it.
    "045_auto_knowledge_local_recovery_reasons.sql": 45,
    # Migration 046 widens the same immutable recovery ledger for a second,
    # narrowly proven historical replay. Never rebuild it after 046 commits.
    "046_auto_knowledge_legacy_feedback_recovery.sql": 46,
    # Migration 047 adds the only safe recovery reason for staged official
    # courses that were blocked before provider dispatch.
    "047_auto_knowledge_staged_course_workspace_recovery.sql": 47,
    # Migration 048 grants one exact Teaching-Spec REQUIRED-item prompt repair
    # and must never replay after its immutable receipt enum has been widened.
    "048_auto_knowledge_required_item_repair.sql": 48,
    # Migration 049 records one local-only replay after a short-lived release
    # changed the common base Prompt and consumed the generic artifact replay.
    "049_auto_knowledge_base_prompt_hash_restore.sql": 49,
    # Migration 050 grants one exact SECTION_MAP duplicate-key prompt repair.
    "050_auto_knowledge_unique_key_repair.sql": 50,
    # Migration 051 grants one exact Teaching-Spec atomic-evidence prompt repair.
    "051_auto_knowledge_evidence_scope_repair.sql": 51,
    # Migration 052 adds the only local-only recovery that may remove surplus
    # cross-node citations from a complete, already-metered r3 response.
    "052_auto_knowledge_evidence_scope_normalization.sql": 52,
    # Migration 053 grants one retry only when V52's local normalization was
    # stopped by an input-hash reconstruction defect before writing an artifact.
    "053_auto_knowledge_evidence_scope_normalization_retry.sql": 53,
    # Migration 054 scopes atomic-evidence recovery uniqueness to the frozen
    # shard list, so one course cannot consume another shard's one-shot repair.
    "054_auto_knowledge_per_shard_evidence_recovery_receipts.sql": 54,
    # Migration 055 records the one safe resume after V54's short-lived
    # global normalization lookup stopped an otherwise authorized new shard.
    "055_auto_knowledge_evidence_scope_resume.sql": 55,
    # Migrations 062 and 063 rebuild the immutable recovery-receipt enum.
    # Replaying either after the later schema has committed would narrow the
    # table again while 086/087 are skipped, reproducing the production
    # ledger/table mismatch that blocked INTERNAL_METERING_WORKSPACE_V1.
    "062_auto_knowledge_spec_split_resume.sql": 87,
    "063_auto_knowledge_spec_split_source_replay.sql": 87,
    # SQLite has no portable ADD COLUMN IF NOT EXISTS. Migration 059 links
    # immutable document versions to durable objects and is therefore a
    # deliberately one-shot schema alteration; its own ledger row is the
    # restart-safe replay guard.
    "059_storage_document_versions.sql": 59,
    # Migration 064 adds leased configured-assessment preparation columns.
    # SQLite cannot express these ALTERs idempotently, so its own ledger row is
    # the restart-safe replay guard.
    "064_durable_assessment_preparation.sql": 64,
    # Migration 069 adds renderer cold-start receipt columns. Its own ledger
    # row is the restart-safe guard for SQLite's non-idempotent ADD COLUMN.
    "069_visual_renderer_cold_start_receipts.sql": 69,
    # Migration 072 likewise adds two columns that cannot be made idempotent
    # with CREATE TABLE IF NOT EXISTS, so its ledger row is the replay guard.
    "072_assessment_preparation_retry_epochs.sql": 72,
}
LATEST_V2_SCHEMA_VERSION = 10
LATEST_V3_SCHEMA_VERSION = 89

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS courses (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    owner_user_id TEXT,
    course_type TEXT NOT NULL DEFAULT 'official'
        CHECK (course_type IN ('official', 'user')),
    visibility TEXT NOT NULL DEFAULT 'public'
        CHECK (visibility IN ('private', 'public')),
    preferred_language TEXT NOT NULL DEFAULT 'auto'
        CHECK (preferred_language IN ('auto', 'zh-CN', 'en', 'bilingual')),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    CHECK (
        (course_type = 'official' AND owner_user_id IS NULL)
        OR (course_type = 'user' AND owner_user_id IS NOT NULL)
    )
);

CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    media_type TEXT NOT NULL,
    extension TEXT NOT NULL,
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
    byte_size INTEGER NOT NULL DEFAULT 0 CHECK (byte_size >= 0),
    status TEXT NOT NULL
        CHECK (status IN ('pending', 'processing', 'ready', 'failed', 'unsupported')),
    chunk_count INTEGER NOT NULL DEFAULT 0 CHECK (chunk_count >= 0),
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (course_id, sha256)
);

CREATE TABLE IF NOT EXISTS ingestion_jobs (
    id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('queued', 'processing', 'completed', 'failed')),
    processed_chunks INTEGER NOT NULL DEFAULT 0 CHECK (processed_chunks >= 0),
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS chunks (
    id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    content TEXT NOT NULL CHECK (length(trim(content)) > 0),
    locator_type TEXT NOT NULL,
    locator_value TEXT NOT NULL,
    section TEXT,
    metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json)),
    parent_key TEXT,
    embedding TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (document_id, ordinal)
);

CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    owner_user_id TEXT NOT NULL,
    course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT 'New Conversation'
        CHECK (length(trim(title)) BETWEEN 1 AND 120),
    preferred_language TEXT NOT NULL DEFAULT 'auto'
        CHECK (preferred_language IN ('auto', 'zh-CN', 'en', 'bilingual')),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL CHECK (length(trim(content)) > 0),
    citations_json TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(citations_json)),
    metadata_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json)),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_documents_course ON documents(course_id, created_at);
CREATE INDEX IF NOT EXISTS idx_chunks_course ON chunks(course_id, document_id, ordinal);
CREATE INDEX IF NOT EXISTS idx_jobs_document ON ingestion_jobs(document_id, created_at);
CREATE INDEX IF NOT EXISTS idx_conversations_course ON conversations(course_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS rate_limit_windows (
    owner_user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    window_start INTEGER NOT NULL,
    request_count INTEGER NOT NULL CHECK (request_count >= 0),
    PRIMARY KEY (owner_user_id, action, window_start)
);

CREATE TABLE IF NOT EXISTS course_teaching_profiles (
    id TEXT PRIMARY KEY,
    course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    version INTEGER NOT NULL CHECK (version >= 1),
    created_by_user_id TEXT NOT NULL,
    language TEXT NOT NULL CHECK (language IN ('auto', 'zh-CN', 'en', 'bilingual')),
    student_level TEXT NOT NULL CHECK (student_level IN ('beginner', 'intermediate', 'advanced')),
    learning_goal TEXT NOT NULL,
    teaching_styles_json TEXT NOT NULL CHECK (json_valid(teaching_styles_json)),
    answer_depth TEXT NOT NULL CHECK (answer_depth IN ('concise', 'balanced', 'detailed')),
    example_preference TEXT NOT NULL
        CHECK (example_preference IN ('minimal', 'when-helpful', 'worked')),
    exercise_policy TEXT NOT NULL CHECK (exercise_policy IN ('none', 'offer', 'always')),
    exam_orientation INTEGER NOT NULL DEFAULT 0 CHECK (exam_orientation IN (0, 1)),
    citation_preference TEXT NOT NULL CHECK (citation_preference IN ('standard', 'detailed')),
    math_detail_level TEXT NOT NULL CHECK (math_detail_level IN ('light', 'standard', 'full')),
    terminology_style TEXT NOT NULL CHECK (terminology_style IN ('plain', 'bilingual', 'formal')),
    custom_requirements TEXT NOT NULL DEFAULT '',
    generated_prompt TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (course_id, version)
);

CREATE TABLE IF NOT EXISTS course_publication_requests (
    id TEXT PRIMARY KEY,
    course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    owner_user_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn')),
    share_materials_consent INTEGER NOT NULL CHECK (share_materials_consent = 1),
    rights_confirmation INTEGER NOT NULL CHECK (rights_confirmation = 1),
    consent_version TEXT NOT NULL,
    consented_at TEXT NOT NULL,
    submitted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    reviewed_at TEXT,
    reviewed_by_user_id TEXT,
    review_note TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_profiles_course_version
ON course_teaching_profiles(course_id, version DESC);
CREATE INDEX IF NOT EXISTS idx_publication_status_submitted
ON course_publication_requests(status, submitted_at);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    content,
    chunk_id UNINDEXED,
    course_id UNINDEXED,
    tokenize = 'unicode61'
);

CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
    INSERT INTO chunks_fts(rowid, content, chunk_id, course_id)
    VALUES (new.rowid, new.content, new.id, new.course_id);
END;

CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
    DELETE FROM chunks_fts WHERE rowid = old.rowid;
END;

CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE OF content, id, course_id ON chunks BEGIN
    DELETE FROM chunks_fts WHERE rowid = old.rowid;
    INSERT INTO chunks_fts(rowid, content, chunk_id, course_id)
    VALUES (new.rowid, new.content, new.id, new.course_id);
END;

CREATE TRIGGER IF NOT EXISTS course_activity_document_ai AFTER INSERT ON documents BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = new.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_document_au AFTER UPDATE ON documents BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = new.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_document_ad AFTER DELETE ON documents BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = old.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_conversation_ai AFTER INSERT ON conversations BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = new.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_conversation_au AFTER UPDATE ON conversations BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = new.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_conversation_ad AFTER DELETE ON conversations BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = old.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_profile_ai
AFTER INSERT ON course_teaching_profiles BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = new.course_id;
END;

CREATE TRIGGER IF NOT EXISTS course_activity_profile_ad
AFTER DELETE ON course_teaching_profiles BEGIN
    UPDATE courses SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = old.course_id;
END;
"""


class Database:
    """Own SQLite connections and initialize the RAG schema."""

    def __init__(self, settings: Settings) -> None:
        self.path = settings.database_path
        self.upload_dir = settings.upload_dir
        self.storage_cache_dir = settings.storage_cache_dir
        self.storage_path_resolver = None
        self.storage_object_probe = None
        self.storage_range_resolver = None
        self.v3_enabled = settings.v3_enabled

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(SCHEMA_SQL)
            columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(conversations)")
            }
            v2_applied = connection.execute(
                "SELECT 1 FROM schema_migrations WHERE version = 2"
            ).fetchone() is not None
            if "owner_user_id" not in columns:
                connection.execute(
                    "ALTER TABLE conversations ADD COLUMN owner_user_id "
                    "TEXT NOT NULL DEFAULT 'legacy_orphaned'"
                )
            if "title" not in columns:
                connection.execute(
                    "ALTER TABLE conversations ADD COLUMN title "
                    "TEXT NOT NULL DEFAULT 'New Conversation'"
                )
            if "preferred_language" not in columns:
                connection.execute(
                    "ALTER TABLE conversations ADD COLUMN preferred_language "
                    "TEXT NOT NULL DEFAULT 'auto' "
                    "CHECK (preferred_language IN ('auto', 'zh-CN', 'en', 'bilingual'))"
                )
            connection.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_conversations_owner_updated
                ON conversations(owner_user_id, updated_at);
                CREATE INDEX IF NOT EXISTS idx_conversations_owner_course_updated
                ON conversations(owner_user_id, course_id, updated_at);
                INSERT OR IGNORE INTO schema_migrations (version, name)
                VALUES (1, 'conversation ownership and per-user limits');
                """
            )
            course_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(courses)")
            }
            if "owner_user_id" not in course_columns:
                connection.execute("ALTER TABLE courses ADD COLUMN owner_user_id TEXT")
            if "course_type" not in course_columns:
                connection.execute(
                    "ALTER TABLE courses ADD COLUMN course_type "
                    "TEXT NOT NULL DEFAULT 'official'"
                )
            if "visibility" not in course_columns:
                connection.execute(
                    "ALTER TABLE courses ADD COLUMN visibility "
                    "TEXT NOT NULL DEFAULT 'public'"
                )
            if "updated_at" not in course_columns:
                connection.execute("ALTER TABLE courses ADD COLUMN updated_at TEXT")
            connection.execute(
                """
                UPDATE courses
                SET updated_at = COALESCE(
                    NULLIF(updated_at, ''),
                    NULLIF(created_at, ''),
                    strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                )
                WHERE updated_at IS NULL OR updated_at = ''
                """
            )
            connection.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_courses_visibility_owner
                ON courses(visibility, owner_user_id, updated_at);
                INSERT OR IGNORE INTO schema_migrations (version, name)
                VALUES (5, 'private user courses and ownership');
                """
            )
            conversation_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(conversations)")
            }
            if "teaching_profile_version" not in conversation_columns:
                connection.execute(
                    "ALTER TABLE conversations ADD COLUMN teaching_profile_version INTEGER"
                )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (6, "versioned course teaching profiles"),
            )
            if "publication_status" not in course_columns:
                connection.execute(
                    "ALTER TABLE courses ADD COLUMN publication_status "
                    "TEXT NOT NULL DEFAULT 'private'"
                )
                connection.execute(
                    "UPDATE courses SET publication_status = 'published' "
                    "WHERE course_type = 'official'"
                )
            if "published_at" not in course_columns:
                connection.execute("ALTER TABLE courses ADD COLUMN published_at TEXT")
                connection.execute(
                    "UPDATE courses SET published_at = created_at "
                    "WHERE course_type = 'official'"
                )
            if "preferred_language" not in course_columns:
                connection.execute(
                    "ALTER TABLE courses ADD COLUMN preferred_language "
                    "TEXT NOT NULL DEFAULT 'auto' "
                    "CHECK (preferred_language IN ('auto', 'zh-CN', 'en', 'bilingual'))"
                )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (7, "consent based course publication workflow"),
            )
            document_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(documents)")
            }
            if "byte_size" not in document_columns:
                connection.execute(
                    "ALTER TABLE documents ADD COLUMN byte_size INTEGER NOT NULL DEFAULT 0 "
                    "CHECK (byte_size >= 0)"
                )
            for document in connection.execute(
                "SELECT id, stored_path FROM documents WHERE byte_size = 0"
            ).fetchall():
                stored_path = Path(document["stored_path"])
                try:
                    byte_size = stored_path.stat().st_size
                except OSError:
                    continue
                connection.execute(
                    "UPDATE documents SET byte_size = ? WHERE id = ?",
                    (byte_size, document["id"]),
                )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (8, "user course storage quotas"),
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (9, "course language preference"),
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (10, "course activity timestamps"),
            )
            if not v2_applied:
                connection.executescript(
                    """
                    UPDATE conversations
                    SET title = COALESCE(
                        NULLIF(substr((
                            SELECT trim(content)
                            FROM messages
                            WHERE messages.conversation_id = conversations.id
                              AND messages.role = 'user'
                            ORDER BY messages.created_at, messages.rowid
                            LIMIT 1
                        ), 1, 80), ''),
                        'New Conversation'
                    )
                    WHERE title = 'New Conversation';
                    INSERT OR IGNORE INTO schema_migrations (version, name)
                    VALUES (2, 'conversation history metadata');
                    """
                )
            message_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(messages)")
            }
            if "metadata_json" not in message_columns:
                connection.execute(
                    "ALTER TABLE messages ADD COLUMN metadata_json "
                    "TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json))"
                )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations (version, name) VALUES (?, ?)",
                (3, "assistant message routing metadata"),
            )
            chunk_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(chunks)")
            }
            if "metadata_json" not in chunk_columns:
                connection.execute(
                    "ALTER TABLE chunks ADD COLUMN metadata_json "
                    "TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(metadata_json))"
                )
            if "parent_key" not in chunk_columns:
                connection.execute("ALTER TABLE chunks ADD COLUMN parent_key TEXT")
            connection.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_chunks_course_parent
                ON chunks(course_id, parent_key, ordinal);
                INSERT OR IGNORE INTO schema_migrations (version, name)
                VALUES (4, 'structured chunk metadata');
                """
            )

        if self.v3_enabled:
            with self.connect() as connection:
                applied_versions = {
                    int(row[0])
                    for row in connection.execute(
                        "SELECT version FROM schema_migrations"
                    ).fetchall()
                }
                for name in V3_MIGRATIONS:
                    version = int(name.split("_", 1)[0])
                    superseding_version = V3_REPLAY_SUPERSEDED_BY.get(name)
                    if (
                        version in applied_versions
                        and superseding_version is not None
                        and superseding_version in applied_versions
                    ):
                        continue
                    if version == 23:
                        # Later append views reference this guarded column.
                        # Install it at its owning migration, before a later
                        # table rename makes SQLite validate those views.
                        tree_columns = {
                            row["name"] for row in connection.execute(
                                "PRAGMA table_info(knowledge_tree_versions)"
                            )
                        }
                        if "corpus_fingerprint" not in tree_columns:
                            connection.execute(
                                "ALTER TABLE knowledge_tree_versions ADD COLUMN "
                                "corpus_fingerprint TEXT CHECK (corpus_fingerprint IS NULL "
                                "OR length(corpus_fingerprint) = 64)"
                            )
                        connection.execute(
                            "CREATE INDEX IF NOT EXISTS idx_official_draft_corpus_fingerprint "
                            "ON knowledge_tree_versions(course_id, corpus_fingerprint) "
                            "WHERE tree_kind = 'OFFICIAL' AND status = 'DRAFT'"
                        )
                    if version == 77:
                        # Migration 044's guarded ALTER historically runs after
                        # this loop. The role-ledger rebuild in 077 must also
                        # see quota_scope when initializing a fresh database.
                        reservation_columns = {
                            row["name"]
                            for row in connection.execute(
                                "PRAGMA table_info(learning_model_call_reservations)"
                            )
                        }
                        if "quota_scope" not in reservation_columns:
                            connection.execute(
                                "ALTER TABLE learning_model_call_reservations ADD COLUMN "
                                "quota_scope TEXT NOT NULL DEFAULT 'INTERACTIVE' "
                                "CHECK(quota_scope IN ('INTERACTIVE','BACKGROUND_AUTO_MAP'))"
                            )
                    connection.executescript(
                        (Path(__file__).parent.parent / "migrations" / name).read_text(
                            encoding="utf-8"
                        )
                    )
                    applied_versions.add(version)
                # Migration 025 columns are conditional ALTERs (SQLite cannot
                # ADD COLUMN IF NOT EXISTS); ledger entry lives in the SQL file.
                course_columns = {
                    row["name"]
                    for row in connection.execute("PRAGMA table_info(courses)")
                }
                if "display_type" not in course_columns:
                    connection.execute(
                        "ALTER TABLE courses ADD COLUMN display_type TEXT "
                        "CHECK (display_type IN ('private','campus','shared'))"
                    )
                if "requires_student_verification" not in course_columns:
                    connection.execute(
                        "ALTER TABLE courses ADD COLUMN "
                        "requires_student_verification INTEGER NOT NULL DEFAULT 0"
                    )
                if "display_type" not in course_columns:
                    connection.execute(
                        "UPDATE courses SET display_type='campus', "
                        "requires_student_verification=1 WHERE course_type='official'"
                    )
                    connection.execute(
                        "UPDATE courses SET display_type='private' "
                        "WHERE course_type != 'official'"
                    )
                # Migration 035 columns are conditional ALTERs for the same reason (ledger entry
                # lives in the SQL file). They describe a credential the database must never
                # hold: an opaque reference, whether it was a transient task credential or a
                # saved connection, and the lifecycle state of that credential.
                job_columns = {
                    row["name"]
                    for row in connection.execute("PRAGMA table_info(canvas_import_jobs)")
                }
                if job_columns:
                    if "credential_ref" not in job_columns:
                        connection.execute(
                            "ALTER TABLE canvas_import_jobs ADD COLUMN "
                            "credential_ref TEXT NOT NULL DEFAULT ''"
                        )
                    if "credential_kind" not in job_columns:
                        connection.execute(
                            "ALTER TABLE canvas_import_jobs ADD COLUMN "
                            "credential_kind TEXT NOT NULL DEFAULT 'connection' "
                            "CHECK(credential_kind IN ('connection','transient_task'))"
                        )
                    if "credential_state" not in job_columns:
                        connection.execute(
                            "ALTER TABLE canvas_import_jobs ADD COLUMN "
                            "credential_state TEXT NOT NULL DEFAULT 'NEVER_STORED' "
                            "CHECK(credential_state IN ('NEVER_STORED','PRESENT_TRANSIENTLY',"
                            "'DESTROYING','DESTROYED','EXPIRED','LOST_ON_RESTART'))"
                        )
                    connection.execute(
                        "CREATE INDEX IF NOT EXISTS idx_canvas_jobs_credential "
                        "ON canvas_import_jobs(credential_ref)"
                    )
                # Migration 041 adds the digest of the portable bridge's rotated session
                # credential. Like migrations 023/025/035 above, the ALTER is guarded here
                # because SQLite has no ADD COLUMN IF NOT EXISTS and every migration script is
                # intentionally safe to replay during initialization.
                local_session_columns = {
                    row["name"]
                    for row in connection.execute("PRAGMA table_info(canvas_local_sessions)")
                }
                if local_session_columns and "bridge_token_hash" not in local_session_columns:
                    connection.execute(
                        "ALTER TABLE canvas_local_sessions ADD COLUMN "
                        "bridge_token_hash TEXT NOT NULL DEFAULT ''"
                    )
                # Migration 044 gives course-scale background generation its own
                # metering scope without weakening the learner's interactive
                # daily quota. SQLite cannot ADD COLUMN IF NOT EXISTS, so keep
                # the replay-safe guard beside the earlier conditional ALTERs.
                reservation_columns = {
                    row["name"]
                    for row in connection.execute(
                        "PRAGMA table_info(learning_model_call_reservations)"
                    )
                }
                if reservation_columns and "quota_scope" not in reservation_columns:
                    connection.execute(
                        "ALTER TABLE learning_model_call_reservations ADD COLUMN "
                        "quota_scope TEXT NOT NULL DEFAULT 'INTERACTIVE' "
                        "CHECK(quota_scope IN ('INTERACTIVE','BACKGROUND_AUTO_MAP'))"
                    )
                connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_model_call_interactive_owner_day "
                    "ON learning_model_call_reservations(owner_user_id,course_id,created_at) "
                    "WHERE quota_scope='INTERACTIVE'"
                )
                # Migration 057 keeps the existing path columns readable during
                # dual-read migration and adds only an optional durable object link.
                document_columns = {
                    row["name"]
                    for row in connection.execute("PRAGMA table_info(documents)")
                }
                if "storage_object_id" not in document_columns:
                    connection.execute(
                        "ALTER TABLE documents ADD COLUMN storage_object_id TEXT "
                        "REFERENCES storage_objects(id)"
                    )
                connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_documents_storage_object "
                    "ON documents(storage_object_id)"
                )

    def is_ready(self) -> bool:
        if not self.upload_dir.is_dir():
            return False
        connection: sqlite3.Connection | None = None
        try:
            database_uri = f"{self.path.resolve().as_uri()}?mode=ro"
            connection = sqlite3.connect(database_uri, uri=True, timeout=10)
            connection.execute("PRAGMA busy_timeout = 10000")
            required_version = (
                LATEST_V3_SCHEMA_VERSION
                if self.v3_enabled
                else LATEST_V2_SCHEMA_VERSION
            )
            applied_versions = {
                int(row[0])
                for row in connection.execute(
                    "SELECT version FROM schema_migrations WHERE version <= ?",
                    (required_version,),
                )
            }
            return applied_versions == set(range(1, required_version + 1))
        except sqlite3.Error:
            return False
        finally:
            if connection is not None:
                connection.close()

    def consume_rate_limit(
        self,
        *,
        owner_user_id: str,
        action: str,
        limit: int,
        now_epoch_seconds: int,
    ) -> bool:
        window_start = now_epoch_seconds - (now_epoch_seconds % 60)
        with self.connect() as connection:
            connection.execute(
                "DELETE FROM rate_limit_windows WHERE window_start < ?",
                (window_start - 3_600,),
            )
            row = connection.execute(
                """
                INSERT INTO rate_limit_windows (
                    owner_user_id, action, window_start, request_count
                ) VALUES (?, ?, ?, 1)
                ON CONFLICT(owner_user_id, action, window_start)
                DO UPDATE SET request_count = request_count + 1
                RETURNING request_count
                """,
                (owner_user_id, action, window_start),
            ).fetchone()
        return row is not None and int(row["request_count"]) <= limit
